Hotel Beach Night — Android app project

এই ফোল্ডারটি Android Studio-তে খোলার জন্য Android project source। এটি এখনো APK ফাইল নয়।

অ্যাপের বর্তমান সুবিধা:
- ইংরেজি ও আরবি ইন্টারফেস
- ৫০টি রুম; Single, Double, Single with Hall
- কাস্টমারের তথ্য, মাসিক ভাড়া, পেমেন্ট ও বকেয়া
- আজ/আগামীকাল/বকেয়া/নিজস্ব তারিখের Check-out তালিকা
- রুম নম্বর পরিবর্তন ও occupied room validation
- JSON backup export/import
- এই Android ডিভাইসের WebView storage-এ স্থানীয়ভাবে ডেটা রাখে; অফলাইনে কাজ করার জন্য ডিজাইন করা

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio → Open → এই HotelBeachNightAndroid ফোল্ডারটি নির্বাচন করুন।
3. Gradle sync সম্পন্ন হতে দিন এবং Android SDK Platform 35 ইনস্টল করুন।
4. Build → Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

সীমাবদ্ধতা:
- এই পরিবেশে Android SDK/Gradle build tool নেই, তাই এখানে APK compile করা হয়নি।
- Cloud backup/sync, login, server database এবং encryption এখনো যুক্ত নয়।
- বাস্তব জাতীয় পরিচয়পত্র/ইকামা তথ্য রাখার আগে নিরাপদ authentication, encryption ও cloud backend যুক্ত করা দরকার।
- Settings & Backup থেকে JSON backup নিয়মিত export করে নিরাপদ জায়গায় রাখুন।
